<?php get_header(); ?>

    <main>
        <div class="page_default">
            
            <div class="container" style=" padding: 40px 10px">
                <h2 style="color: #ffffff; text-align: center; width: 100%;">404</h2>
                <p style="color: #ffffff; width: 100%; text-align: center ">Página não encontrada :(</p>
            </div>

        </div>
    </main>

<?php get_footer(); ?>