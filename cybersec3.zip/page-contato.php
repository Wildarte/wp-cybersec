<?php get_header();
//Template Name: Page Contato
?>

    <main>
        <section class="section_contact">
            <div class="container content_section_contact d-flex">
                <div class="f-40 left_contact">
                    <h2>Como posso ajudar?</h2>

                    <p>Estamos disponíveis e ficaremos felizes em ajudá-lo. Preencha o formulário e clique em enviar. Responderemos em breve.</p>
                </div>

                <div class="f-60">
                    <div class="form_over">

                        <img class="img_form_over" src="<?= get_template_directory_uri(); ?>/assets/img/caixa.png" alt="">

                        <?= do_shortcode('[contact-form-7 id="100" title="Formulário de contato 1"]'); ?>
                        
                        <script>

                            document.addEventListener('DOMContentLoaded', () => {
                                const img_form = document.querySelector('.form_over .img_form_over');
                                const form_contact = document.querySelector('.form_over form');
                                let height_img_form = img_form.getBoundingClientRect().height;
                                form_contact.style.height = height_img_form+"px";
                                console.log(height_img_form);
                            })
                            
                            let current_width = window.innerWidth;

                            window.addEventListener('resize', (e) => {
                                console.log(current_width);
                                if(window.matchMedia('(max-width: 768px').matches){
                                    
                                    form_contact.style.height = 'unset';
                                    
                                }else{
                                    let height_img_form = img_form.getBoundingClientRect().height;
                                    form_contact.style.height = height_img_form+"px";
                                }
                                
                            });

                            window.sc
                        </script>
                    </div>

                </div>
            </div>
        </section>
    </main>

<?php get_footer(); ?>